<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "paynplay";
$port = 3307; // Defaulting to 3307 based on XAMPP setup

$conn = new mysqli($host, $user, $pass, $db, $port);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>